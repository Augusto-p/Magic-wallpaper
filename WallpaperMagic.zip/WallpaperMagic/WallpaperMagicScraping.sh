#!/bin/bash

urlbase="https://www.hdcarwallpapers.com"
url="https://www.hdcarwallpapers.com/random_wallpapers"

html=$(wget -qO- $url)
html=$(echo "$html" | tr '\n' ' ')
ul=$(echo "$html" | sed 's/.*<ul class="wallpapers">//')
urlwal=$(echo "$ul" | grep -oP 'href="\K[^"]+' | head -n 1)
wallpaper=$(wget -qO- $urlbase$urlwal)
wallpaper=$(echo "$wallpaper" | tr '\n' ' ')
span=$(echo "$wallpaper" | sed 's/.*<span class="original">//')
urlWallpaper=$(echo "$span" | grep -oP 'href="\K[^"]+' | head -n 1)
ext=$(echo "$urlWallpaper" | cut -d '.' -f 2)
name="$1$2.$ext"
echo $name

wget -O $name $urlbase$urlWallpaper

# body=${parts[1]}

# echo $body


