#!/bin/bash
 
directory="/WallpaperMaigic/tmp"
path=
if [ ! -d $directory ];then
	mkdir -p $directory
fi

lsN=$(find $directory -maxdepth 1 -type f | wc -l)
if [ "$lsN" -lt 6 ];then
	if ! ping -c 1 8.8.8.8 &> /dev/null;then
		echo "Sin Conexion a Internet"
	else
		echo "Conectado a Internet"
		for i in $(seq $lsN 5); do
			/home/augusto/Documentos/WallpaperMagic/WallpaperMagicScraping.sh "$directory/" $i
		done
	fi
fi



