#!/bin/bash

directory="/WallpaperMaigic/tmp"

if [ ! -d $directory ];then
	echo "Carpeta no Existente"

else
	lsN=$(find $directory -maxdepth 1 -type f | wc -l)
	if [ "$lsN" -gt 1 ];then
		name="/0*"
		cerofile=$(ls $directory$name )
		rm -f $cerofile
		for i in $(seq 1 $(($lsN-1)));do
			namef="/$i*"
			namefile=$(ls $directory$namef)
			newname="/$((i-1))."
			IFS="." read -ra partes <<< "$namefile"
			ext="${partes[-1]}"
			newnamefile=$directory$newname$ext
			mv $namefile $newnamefile
		done

		# set  new cerofile backraund
		#GNOME
		if [[ $XDG_CURRENT_DESKTOP == "GNOME" ]];then
			for user in $(awk -F ':' '/WallpaperMagic/{print $4}' /etc/group | tr ',' "\n");do
				folder=$(awk -F ':' "/$user/"'{print $6}' /etc/passwd)
				cp $cerofile  $folder/.config/background 
			done
		fi
	fi
fi

