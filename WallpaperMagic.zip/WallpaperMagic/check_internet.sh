#!/bin/bash

# Dirección de host que siempre debe estar accesible, como un DNS público
HOST="8.8.8.8"

# Ping para verificar la conectividad
if ping -c 1 $HOST &> /dev/null
then
  # Ejecuta el script si hay conexión a Internet
  /home/augusto/Documentos/WallpaperMagic/WallpaperMagicInternetDemon.sh
fi
